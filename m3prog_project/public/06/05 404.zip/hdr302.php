<?php

header("Location: https://www.youtube.com/watch?v=B02Y_yEGlNI" "302 not found");


?>

<!-- http://localhost:88/06/hdr302.php -->