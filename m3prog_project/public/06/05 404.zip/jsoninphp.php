<?php


$steden = json_encode([
    "Amsterdam",
    "Rotterdam",
    "Utrecht",
    "Den Haag"
]);

echo $steden;
