De volledige URL die is opgevraagd
De request method (verzoek method in het Nederlands)
De status code (3-cijferig getal)
Zoek hier op bij welke van de 5 categorieën codes deze code hoort.
In welke request header staat de informatie over je webbrowser en systeem?



1. De volledige URL die is opgevraagd:
https://rr5---sn-5hne6n6e.googlevideo.com/videoplayback?expire=1743104514&ei=olXlZ4qYHPS26dsPxq3rgA0&ip=145.102.244.50&id=o-AO9catswR_GT0E18-aCsegszsflQsWeqcMvyBf1ytTeH&source=youtube&requiressl=yes&xpc=EgVo2aDSNQ%3D%3D&met=1743082914%2C&mh=ys&mm=31%2C26&mn=sn-5hne6n6e%2Csn-4g5lznlz&ms=au%2Conr&mv=m&mvi=5&pl=16&rms=au%2Cau&initcwndbps=4655000&siu=1&spc=_S3wKqqT3XboCuvGEehml-vQyRcqSEHqUcXIbzhLpgYyADG-SENKnIqMYAtiClv2N-fjNRg3Rrak2LZp&svpuc=1&ns=XL6bleF1HAkTPDL84JEr_9kQ&sabr=1&rqh=1&mt=1743082402&fvip=5&keepalive=yes&fexp=51355912%2C51435732&c=WEB&n=rCrCb_q0K0Ei2A&sparams=expire%2Cei%2Cip%2Cid%2Csource%2Crequiressl%2Cxpc%2Csiu%2Cspc%2Csvpuc%2Cns%2Csabr%2Crqh&sig=AJfQdSswRAIgce8MhfZ8N9EbfT4JxUxJCt_GKgbtbZMiLxx8kRVIqJ4CID0E_XD2_bMp7Z8YGc7TCVKDjn77y4_Ry14ShDoRG2wG&lsparams=met%2Cmh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Crms%2Cinitcwndbps&lsig=AFVRHeAwRQIgAN72fwbShuXyOzLKv4HqHjzMn-Q5nQfTpHYncGwjXF0CIQDYmj4wh38F0xXN7WwuWv3nibBZWnvR2AcJrnLOx8cppQ%3D%3D&cpn=q0YKQ2YD2GMFJuUl&cver=2.20250324.09.00&rn=23&alr=yes

2. De request method is POST

3. status code 200 OK

4. succesvol responses

5. (origin:
https://www.youtube.com

sec-ch-ua-platform:
"Windows")



1. de volledige URL die is opgevraagd:
https://www.youtube.com/api/stats/qoe?cpn=q0YKQ2YD2GMFJuUl&el=detailpage&ns=yt&fexp=v1%2C23986026%2C18618%2C434717%2C127326%2C133212%2C14625955%2C11684381%2C53408%2C9105%2C18310%2C4420%2C2821%2C78212%2C8479%2C18027%2C1312%2C18644%2C9664%2C5205%2C47210%2C15124%2C65%2C13526%2C391%2C6154%2C17717%2C2633%2C9252%2C3479%2C690%2C1829%2C10511%2C2975%2C2360%2C3889%2C3407%2C4114%2C6461%2C238%2C358%2C1030%2C6076%2C7477%2C2%2C1900%2C733%2C663%2C2%2C1227%2C1629%2C1666%2C912%2C1965%2C5391%2C224%2C3770%2C1136%2C2681%2C3115%2C128%2C1870%2C1353%2C87%2C3359%2C100%2C935%2C106%2C926%2C4544&cl=740099560&seq=1&docid=sBJmRD7kNTk&ei=olXlZ4qYHPS26dsPxq3rgA0&event=streamingstats&feature=g-high-rec&plid=AAYxUx3uhddD-Akl&sdetail=p%3A%2F&sourceid=y&cbr=Chrome&cbrver=134.0.0.0&c=WEB&cver=2.20250324.09.00&cplayer=UNIPLAYER&cos=Windows&cosver=10.0&cplatform=DESKTOP&vps=0.000:N,0.004:B,0.018:N,0.019:SU,0.019:SU&cat=streaming,sabr&ctmp=esfw:usbc.1;hsu.1&cmt=0.004:0.000,0.018:0.000,0.019:0.000,0.019:0.000&bat=0.019:0.8:1&vis=0.019:5&bh=0.019:0.000&qclc=ChBxMFlLUTJZRDJHTUZKdVVsEAE

2. De request method is POST

3. status code: 204 No content

4. succesvol responses

5. (origin:
https://www.youtube.com

priority:
u=1, i)



1. de volledige URL die is opgevraagd:
https://rr5---sn-5hne6n6e.googlevideo.com/videoplayback?expire=1743104514&ei=olXlZ4qYHPS26dsPxq3rgA0&ip=145.102.244.50&id=o-AO9catswR_GT0E18-aCsegszsflQsWeqcMvyBf1ytTeH&source=youtube&requiressl=yes&xpc=EgVo2aDSNQ%3D%3D&met=1743082914%2C&mh=ys&mm=31%2C26&mn=sn-5hne6n6e%2Csn-4g5lznlz&ms=au%2Conr&mv=m&mvi=5&pl=16&rms=au%2Cau&initcwndbps=4655000&siu=1&spc=_S3wKqqT3XboCuvGEehml-vQyRcqSEHqUcXIbzhLpgYyADG-SENKnIqMYAtiClv2N-fjNRg3Rrak2LZp&svpuc=1&ns=XL6bleF1HAkTPDL84JEr_9kQ&sabr=1&rqh=1&mt=1743082402&fvip=5&keepalive=yes&fexp=51355912%2C51435732&c=WEB&n=rCrCb_q0K0Ei2A&sparams=expire%2Cei%2Cip%2Cid%2Csource%2Crequiressl%2Cxpc%2Csiu%2Cspc%2Csvpuc%2Cns%2Csabr%2Crqh&sig=AJfQdSswRAIgce8MhfZ8N9EbfT4JxUxJCt_GKgbtbZMiLxx8kRVIqJ4CID0E_XD2_bMp7Z8YGc7TCVKDjn77y4_Ry14ShDoRG2wG&lsparams=met%2Cmh%2Cmm%2Cmn%2Cms%2Cmv%2Cmvi%2Cpl%2Crms%2Cinitcwndbps&lsig=AFVRHeAwRQIgAN72fwbShuXyOzLKv4HqHjzMn-Q5nQfTpHYncGwjXF0CIQDYmj4wh38F0xXN7WwuWv3nibBZWnvR2AcJrnLOx8cppQ%3D%3D&cpn=YMR--e9qQlfcIFrp&cver=2.20250324.09.00&rn=24&alr=yes

2. De request method is Post 

3. status code 200 OK

4. succesvol responses

5. (origin:
https://www.youtube.com

referer:
https://www.youtube.com/)