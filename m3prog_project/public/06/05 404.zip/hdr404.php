<?php 

header("HTTP/1.1 404 Not Found");


?>


<!-- http://localhost:88/06/hdr404.php -->