Wat staat er in de content-type header van deze pagina?
Wat staat er in de date header?
Wanneer is het document voor het laatst aangepast?

    1. :method: GET

    2. date: Thu, 27 Mar 2025 13:51:57 GMT

    3. een paar uur geleden 